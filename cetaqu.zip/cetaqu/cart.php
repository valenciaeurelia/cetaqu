<?php
require "inc/login_required.php";
require "inc/conn.php";
if (isset($_POST['remove'])){
  $sql = "DELETE FROM carts WHERE user_id = ? AND product_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('ii', $_SESSION['user_id'], $_POST['product_id']);
  $stmt->execute();
}
if (isset($_POST['add'])){
  $sql = "SELECT * FROM carts WHERE user_id = ? AND product_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('ii', $_SESSION['user_id'], $_POST['product_id']);
  $stmt->execute();
  $rs = $stmt->get_result();
  $data = $rs->fetch_assoc();
  if ($data) {
    $qty = $data['qty'] + $_POST['qty'];
    $sql = "UPDATE carts SET qty = ? WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iii', $qty, $_SESSION['user_id'], $_POST['product_id']);
    $stmt->execute();
  } else {
    $sql = "INSERT INTO carts (user_id, product_id, qty) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iii', $_SESSION['user_id'], $_POST['product_id'], $_POST['qty']);
    $stmt->execute();
  }
}
$sql = "SELECT * FROM carts JOIN products ON products.id=carts.product_id WHERE carts.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$rs = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="zxx">
  <head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="assets/css/boxicons.min.css" />
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css" />
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/nice-select.min.css" />
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css" />

    <!-- Style Custom CSS -->
    <link rel="stylesheet" href="assets/css/style-custom.css" />

    <!-- Title -->
    <title>CetaQu</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png" />
  </head>

  <body>
    <!-- Preloader -->
    <div class="preloader">
      <div class="d-table">
        <div class="d-table-cell">
          <div class="pre-img">
            <img src="assets/img/CetaQu.png" alt="Logo" />
          </div>
          <div class="spinner">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="circle3"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <div class="navbar-area">
      <!-- Menu For Mobile Device -->
      <div class="mobile-nav">
        <a href="index.php" class="logo">
          <img src="assets/img/CetaQu.png" alt="Logo" />
        </a>
      </div>

      <!-- Menu For Desktop Device -->
      <div class="main-nav">
        <div class="container">
          <nav class="navbar navbar-expand-md">
            <a class="navbar-brand" href="index.php">
              <img src="assets/img/CetaQu.png" alt="Logo" />
            </a>

            <div
              class="collapse navbar-collapse mean-menu"
              id="navbarSupportedContent"
            >
              <ul class="navbar-nav m-auto">
                <li class="nav-item">
                  <a href="index.php" class="nav-link"> Home </a>
                </li>
                <li class="nav-item">
                  <a href="product.php" class="nav-link"> Products </a>
                </li>
                <li class="nav-item">
                  <a href="about.php" class="nav-link"> About Us </a>
                </li>
                <li class="nav-item">
                  <a href="contact.php" class="nav-link"> Contact </a>
                </li>
              </ul>

              <div class="cart-area">
                <a href="product.php#search">
                  <i class="bx bx-search"></i>
                </a>
                <a href="wishlist.php">
                  <i class="bx bx-heart"></i>
                </a>
                <a href="account.php">
                  <i class="bx bx-user"></i>
                </a>
                <a href="cart.php" style="color: #fb2e86">
                  <i class="bx bx-shopping-bag"></i>
                </a>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!-- End Navbar Area -->

    <!-- Inner Banner -->
    <div class="inner-banner inner-bg19">
      <div class="container">
        <div class="inner-title">
          <h3>Cart</h3>
          <ul>
            <li>
              <a href="index.php">Home</a>
            </li>
            <li>
              <i class="bx bxs-chevrons-right"></i>
            </li>
            <li>Cart</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Inner Banner End -->

    <!-- Start Cart Area -->
    <section class="cart-wraps-area ptb-100">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-12">
              <div class="cart-wraps">
                <div class="cart-table table-responsive">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">Product</th>
                        <th scope="col">Name</th>
                        <th scope="col">Unit Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Total</th>
                      </tr>
                    </thead>

                    <tbody>
                    <?php $total=0;while($data = $rs->fetch_assoc()) {?>
                      <tr>
                        <td class="product-thumbnail">
                          <a href="#">
                            <img
                              src="assets/img/index/product/<?=$data['img']?>"
                              alt="Image"
                            />
                          </a>
                        </td>

                        <td class="product-name">
                          <a href="#"><?=$data['name']?></a>
                        </td>

                        <td class="product-price">
                          <span class="unit-amount">Rp. <?=$data['price']?></span>
                        </td>

                        <td class="product-quantity">
                          <div class="input-counter">
                            <span class="minus-btn">
                              <i class="bx bx-minus"></i>
                            </span>
                            <input type="text" value="<?=$data['qty']?>" />
                            <span class="plus-btn">
                              <i class="bx bx-plus"></i>
                            </span>
                          </div>
                        </td>

                        <td class="product-subtotal">
                          <span class="subtotal-amount">Rp. <?=$data['price']*$data['qty']?></span>
                          <?php $total += $data['price']*$data['qty'] ?>
                          <form action="cart.php" method="POST" style="display: inline;">
                            <input type="hidden" name="product_id" value="<?=$data['id']?>">
                              <button style="border:none; background: none;" type="submit" name="remove">
                              <a class="remove">
                                  <i class='bx bx-trash'></i>
                              </a>
                            </button>
                          </form>
                        </td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>

                <div class="cart-buttons">
                  <div class="row align-items-center">
                    <div class="col-lg-7 col-sm-7 col-md-7">
                      <div class="continue-shopping-box">
                        <a href="product.php" class="default-btn">
                          Continue Shopping
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <form method="post" action="checkout.php" enctype="multipart/form-data">
              <div class="row">
                <div class="col-lg-12">
                  <div class="cart-calc">
                    <div class="cart-wraps-form">
                      <h3>Upload Design</h3>
                      <div class="row">
                        <div class="col-lg-12">
                          Enter your design, according to the terms &
                          conditions. To check terms & conditions, click
                          <a href="terms-condition.php" style="color: #fb2e86"
                            >here</a
                          >
                          <div class="form-group">
                            <div class="image-upload-wrap">
                              <input
                                class="file-upload-input"
                                type="file"
                                onchange="readURL(this);"
                                accept="image/*"
                                name="file_upload"
                              />
                              <div class="drag-text">
                                UPLOAD YOUR DESIGN
                                <i class="bx bx-upload no-hover"></i>
                              </div>
                            </div>
                            <div class="file-upload-content">
                              <img
                                class="file-upload-image"
                                src="#"
                                alt="your image"
                              />
                              <div class="image-title-wrap">
                                <button
                                  type="button"
                                  onclick="removeUpload()"
                                  class="default-btn remove-upload"
                                >
                                  Remove
                                  <span class="image-title"
                                    >Uploaded Image</span
                                  >
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <a href="#" class="default-btn"> Upload Design </a>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="cart-calc">
                    <div class="cart-wraps-form">
                      <h3>COUPON</h3>
                      <div class="form-group">
                        Enter your coupon code if you have one.
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Coupon Code"
                          style="padding: 30px"
                        />
                      </div>
                      <a href="#" class="default-btn"> Apply Coupon </a>
                    </div>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="cart-totals">
                    <h3>Cart Totals</h3>
                    <ul>
                      <li>Subtotal <span>Rp. <?=$total?></span></li>
                      <li>Coupon <span>Rp. 0</span></li>
                      <li>
                        Total <span><b>Rp. <?=$total?></b></span>
                      </li>
                    </ul>
                    
                    <button
                      style="
                        padding: 12px 42px;
                        color: #fff;
                        border: none;
                        border-radius: 5px;
                        text-align: center;
                        position: relative;
                        overflow: hidden;
                        z-index: 1;
                        background-color: #19d16f;
                      "
                      type="submit"
                      name="checkout"
                    >
                      Proceed To Checkout
                    </button>
                  </div>
                </div>
              </div>
              </form>
          </div>
        </div>
      </div>
    </section>
    <!-- End Cart Area -->

    <!-- Footer Area -->
    <footer class="footer-area">
      <div class="container">
        <div class="footer-content">
          <div class="row">
            <div
              class="col-lg-6 col-md-6"
              style="padding-right: 150px; padding-left: 100px"
            >
              <h1>CetaQu</h1>
              <h5>
                A high-quality digital printing for your print division. CetaQu
                Executing Excellence In Printing.
              </h5>
            </div>

            <div class="col-lg-3 col-md-3" style="padding-right: 50px">
              <div class="footer-list">
                <h3>Information</h3>
                <ul>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="about.php">About Us</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="terms-condition.php">Term & Conditions</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="privacy-policy.php">Privacy Policy</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="product.php">Products</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="contact.php">Contact</a>
                  </li>
                </ul>
              </div>
            </div>

            <div class="col-lg-3 col-md-3">
              <div class="footer-side-list">
                <h3>Contact Us</h3>
                <ul>
                  <li>
                    <i class="bx bxs-phone"></i>
                    <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                  </li>
                  <li>
                    <i class="bx bxs-envelope"></i>
                    <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                  </li>
                  <li>
                    <i class="bx bxs-map"></i>
                    <a
                      href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk"
                      >Jl. Scientia Boulevard, <br />Tangerang, Banten 15810</a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <p>©2021 CetaQu. All Rights Reserved</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer Area End -->

    <!-- Jquery Min JS -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <!-- Popper Min JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Meanmenu JS -->
    <script src="assets/js/meanmenu.js"></script>
    <!-- Wow JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Ajaxchimp Min JS -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <!-- Form Validator Min JS -->
    <script src="assets/js/form-validator.min.js"></script>
    <!-- Contact Form JS -->
    <script src="assets/js/contact-form-script.js"></script>
    <!-- Upload Field JS -->
    <script src="assets/js/upload.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/custom.js"></script>
  </body>
</html>
