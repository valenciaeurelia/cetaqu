<?php

require "login_required.php";
if (!$_SESSION['is_admin']){
    header('Location: sign-out.php');
}