<?php

session_start();
if (isset($_SESSION['user_id'])){
    if ($_SESSION['is_admin'] == 1){
        header('Location: admin/orders.php');
        exit;
    }
    header('Location: index.php');
}