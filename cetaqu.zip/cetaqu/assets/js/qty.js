function updateQty(qty) {
    document.querySelectorAll(".qty-input").forEach((input) => {
      input.value = qty;
    });
  }
  
  document.querySelector("#qty").addEventListener("change", function (e) {
    const qty = parseInt(e.target.value);
    updateQty(qty);
  });