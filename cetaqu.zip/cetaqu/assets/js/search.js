const searchInput = document.querySelector("#search > .search-input");
searchInput.addEventListener('keyup', () => {
    const query = searchInput.value.toUpperCase();
    const products = document.querySelectorAll(".product-card");

    for (i = 0; i < products.length; i++) {
        h3 = products[i].getElementsByTagName("h3")[0];
        if (h3) {
            const productName = h3.textContent || h3.innerText || h3.innerHTML;
            if (productName.toUpperCase().indexOf(query) > -1) {
                products[i].parentElement.style.display = "";
            } else {
                products[i].parentElement.style.display = "none";
            }
        }
    }
});