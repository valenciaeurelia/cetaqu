<?php
require "inc/login_required.php";
require "inc/conn.php";

if (isset($_POST['save_account'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $username = $_POST['username'];  
    $email = $_POST['email'];

    $sql = "UPDATE users SET first_name = ?, last_name = ?, username = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $first_name, $last_name, $username, $email, $_SESSION['user_id']);
    $stmt->execute();

    $_SESSION['user']['first_name'] = $first_name;
    $_SESSION['user']['last_name'] = $last_name;
    $_SESSION['user']['username'] = $username;
    $_SESSION['user']['email'] = $email;
}

if (isset($_POST['save_address'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $address_line_1 = $_POST['address_line_1'];
    $address_line_2 = $_POST['address_line_2'];
    $address_line_3 = $_POST['address_line_3'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $sql = "UPDATE users SET first_name = ?, last_name = ?, address_line_1 = ?, address_line_2 = ?, address_line_3 = ?, email = ?, phone = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssssssi', $first_name, $last_name, $address_line_1, $address_line_2, $address_line_3, $email, $phone, $_SESSION['user_id']);
    $stmt->execute();

    $_SESSION['user']['first_name'] = $first_name;
    $_SESSION['user']['last_name'] = $last_name;
    $_SESSION['user']['address_line_1'] = $address_line_1;
    $_SESSION['user']['address_line_2'] = $address_line_2;
    $_SESSION['user']['address_line_3'] = $address_line_3;
    $_SESSION['user']['email'] = $email;
    $_SESSION['user']['phone'] = $phone;
}

if(isset($_POST['received'])){
	$sql = "UPDATE orders SET received_time = ? WHERE id = ?";
	$stmt = $conn->prepare($sql);
	$received_time = date("Y-m-d H:i:s");
	$stmt->bind_param('si', $received_time, $_POST['order_id']);
	$stmt->execute();
}

$sql = "SELECT * FROM order_items JOIN products ON order_items.product_id = products.id";
$stmt = $conn->prepare($sql);
$stmt->execute();
$order_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$sql = "SELECT * FROM orders WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$rs = $stmt->get_result();
$orders = [];
while ($row = $rs->fetch_assoc()) {
	$row['status'] = $row['received_time'] ? 'Received' : ($row['processed_time'] ? 'Processed' : ($row['payment_time'] ? 'Paid' : 'Not Paid'));
	$orders[$row['id']] = $row;
}
foreach ($order_items as $oi) {
    if (!isset($orders[$oi['order_id']])) continue;
	$total = $oi['qty'] * $oi['price'];
	$oi['total'] = $total;
	$orders[$oi['order_id']]['items'][] = $oi;
	$orders[$oi['order_id']]['total'] = isset($orders[$oi['order_id']]['total']) ? ($orders[$oi['order_id']]['total'] + $total) : (0 + $total);
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="assets/css/boxicons.min.css" />
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css" />
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/nice-select.min.css" />
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css" />

    <!-- Style Custom CSS -->
    <link rel="stylesheet" href="assets/css/style-custom.css?t=<?=date('s')?>" />

    <!-- Title -->
    <title>CetaQu</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png" />
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="pre-img">
                    <img src="assets/img/CetaQu.png" alt="Logo" />
                </div>
                <div class="spinner">
                    <div class="circle1"></div>
                    <div class="circle2"></div>
                    <div class="circle3"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <div class="navbar-area">
        <!-- Menu For Mobile Device -->
        <div class="mobile-nav">
            <a href="index.php" class="logo">
                <img src="assets/img/CetaQu.png" alt="Logo" />
            </a>
        </div>

        <!-- Menu For Desktop Device -->
        <div class="main-nav">
            <div class="container">
                <nav class="navbar navbar-expand-md">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/img/CetaQu.png" alt="Logo" />
                    </a>

                    <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                        <ul class="navbar-nav m-auto">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link"> Home </a>
                            </li>
                            <li class="nav-item">
                                <a href="product.php" class="nav-link"> Products </a>
                            </li>
                            <li class="nav-item">
                                <a href="about.php" class="nav-link"> About Us </a>
                            </li>
                            <li class="nav-item">
                                <a href="contact.php" class="nav-link"> Contact </a>
                            </li>
                        </ul>

                        <div class="cart-area">
                            <a href="product.php#search">
                                <i class="bx bx-search"></i>
                            </a>
                            <a href="wishlist.php">
                                <i class="bx bx-heart"></i>
                            </a>
                            <a href="account.php" style="color: #fb2e86">
                                <i class="bx bx-user"></i>
                            </a>
                            <a href="cart.php">
                                <i class="bx bx-shopping-bag"></i>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- End Navbar Area -->

    <!--== Start My Account Wrapper ==-->
    <section class="my-account-area">
        <div class="container pt--0 pb--0">
            <div class="row">
                <div class="col-lg-12">
                    <div class="myaccount-page-wrapper">
                        <div class="row">
                            <div class="col-lg-3 col-md-4">
                                <nav>
                                    <div class="myaccount-tab-menu nav nav-tabs" id="nav-tab" role="tablist">
                                        <a class="nav-link active" id="account-info-tab" data-toggle="tab"
                                            href="#account-info" type="button" role="tab"
                                            aria-controls="account-info" aria-selected="true">
                                            Account Details
                                        </a>

                                        <a class="nav-link" id="my-orders-tab" data-toggle="tab"
                                            href="#my-orders" type="button" role="tab"
                                            aria-controls="my-orders" aria-selected="false">
                                            My Orders
                                        </a>

                                        <a class="nav-link" id="address-tab" data-toggle="tab"
                                            href="#address" type="button" role="tab"
                                            aria-controls="address" aria-selected="false">
                                            Address
                                        </a>

                                        <button class="nav-link" onclick="window.location.href='sign-out.php'"
                                            type="button">
                                            Logout
                                        </button>
                                    </div>
                                </nav>
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="account-info" role="tabpanel"
                                        aria-labelledby="account-info-tab">
                                        <div class="myaccount-content">
                                            <h3>Account Details</h3>
                                            <div class="account-details-form">
                                                <form method="POST">

                                                    <div class="row">

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>First Name <span
                                                                        class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="first_name" value="<?=$_SESSION['user']['first_name']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>Last Name <span class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="last_name" value="<?=$_SESSION['user']['last_name']?>">
                                                            </div>
                                                        </div>


                                                        <div class="col-12">
                                                            <div class="single-input-item">
                                                                <label>Display Name<span class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="username" value="<?=$_SESSION['user']['username']?>">
                                                                <small><em>This will be how your name be displayed in reviews section</em></small>
                                                            </div>
                                                        </div>

                                                        <div class="col-12">
                                                            <div class="single-input-item">
                                                                <label>Email Address <span
                                                                        class="required">*</span></label>
                                                                <input type="email" class="form-control" required name="email" value="<?=$_SESSION['user']['email']?>">
                                                            </div>
                                                        </div>

                                                    </div>
                                                    </fieldset>
                                                    <div class="single-input-item">
                                                        <button type="submit" name="save_account" class="default-btn">
                                                            Save Changes
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="my-orders" role="tabpanel"
                                        aria-labelledby="orders-tab">
                                        <div class="myaccount-content">
                                            <h3>Orders</h3>
                                            <ul class="nav nav-pills orders mb-3" id="pills-tab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="pills-unpaid-tab" data-toggle="pill" href="#pills-unpaid" role="tab" aria-controls="pills-unpaid" aria-selected="true">Not Paid Yet</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="pills-processing-tab" data-toggle="pill" href="#pills-processing" role="tab" aria-controls="pills-processing" aria-selected="false">Processing</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="pills-shipping-tab" data-toggle="pill" href="#pills-shipping" role="tab" aria-controls="pills-shipping" aria-selected="false">Shipping</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="pills-completed-tab" data-toggle="pill" href="#pills-completed" role="tab" aria-controls="pills-completed" aria-selected="false">Completed</a>
                                            </li>
                                            </ul>
                                            <div class="tab-content" id="pills-tabContent">
                                            <div class="tab-pane fade show active" id="pills-unpaid" role="tabpanel" aria-labelledby="pills-unpaid-tab">
                                                <?php foreach ($orders as $order) if ($order['status'] == 'Not Paid'){?>
                                                    <div class="order-details mb-3">
                                                        <div class="order-table table-responsive" style="padding-top: 30px; padding-bottom: 20px;">
                                                            <table>
                                                            <?php foreach ($order['items'] as $item) {?>
                                                                <tr>
                                                                    <td rowspan="2" style="width: 15%; padding: 10px 0 0 0;"><img class="img-fluid" src="assets/img/index/product/<?=$item['img']?>"></td>
                                                                    <td colspan="2" style="vertical-align: bottom;"><h4 style="border: none; padding: 0; margin: 0;"><?=$item['name']?></h4></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="vertical-align: top;">Rp <?=$item['price']?></td>
                                                                    <td style="vertical-align: top; text-align: right;"><?=$item['qty']?>x</td>
                                                                </tr">
                                                            <?php }?>
                                                            </table>
                                                            <table class="table mt-2">
                                                                <tr>
                                                                    <td><?=count($order['items'])?> Products</td>
                                                                    <th class="text-right">Totals Rp <?=$order['total']?></th>
                                                                </tr>
                                                                <tr>
                                                                    <?php
                                                                    $date = new DateTime();
                                                                    $date->modify('+3 days');
                                                                    ?>
                                                                    <td>
                                                                        <p class="text-dark">
                                                                            Make payment before <?=$date->format('d-m-Y H:i')?>
                                                                            <br>
                                                                            See <a href="#my-orders" style="color: #fb2e86;" role="tab" data-toggle="pill">My Orders</a> for more information
                                                                        </p>
                                                                    </td>
                                                                    <td class="text-right"><a href="payment.php?order_id=<?=$order['id']?>" style="
                                                                        padding: 12px 42px;
                                                                        color: #fff;
                                                                        border: none;
                                                                        border-radius: 5px;
                                                                        text-align: center;
                                                                        position: relative;
                                                                        overflow: hidden;
                                                                        z-index: 1;
                                                                        background-color: #19d16f;">
                                                                    Pay Now
                                                            </a></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="tab-pane fade" id="pills-processing" role="tabpanel" aria-labelledby="pills-processing-tab">
                                            <?php foreach ($orders as $order) if ($order['status'] == 'Paid'){?>
                                                <div class="order-details mb-3">
                                                        <div class="order-table table-responsive" style="padding-top: 30px; padding-bottom: 20px;">
                                                            <table>
                                                            <?php foreach ($order['items'] as $item) {?>
                                                                <tr>
                                                                    <td rowspan="2" style="width: 15%; padding: 10px 0 0 0;"><img class="img-fluid" src="assets/img/index/product/<?=$item['img']?>"></td>
                                                                    <td colspan="2" style="vertical-align: bottom;"><h4 style="border: none; padding: 0; margin: 0;"><?=$item['name']?></h4></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="vertical-align: top;">Rp <?=$item['price']?></td>
                                                                    <td style="vertical-align: top; text-align: right;"><?=$item['qty']?>x</td>
                                                                </tr">
                                                            <?php }?>
                                                            </table>
                                                            <table class="table mt-2">
                                                                <tr>
                                                                    <td><?=count($order['items'])?> Products</td>
                                                                    <th class="text-right">Totals Rp <?=$order['total']?></th>
                                                                </tr>
                                                                <tr>
                                                                    <?php
                                                                    $date = new DateTime($order['payment_time']);
                                                                    $date->modify('+3 days');
                                                                    ?>
                                                                    <td>
                                                                        <p class="text-dark">
                                                                            Will be sent before <?=$date->format('d-m-Y H:i')?>.
                                                                            See <a href="#my-orders" style="color: #fb2e86;" role="tab" data-toggle="pill">My Orders</a> for more information
                                                                        </p>
                                                                    </td>
                                                                    <td class="text-right"></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="tab-pane fade" id="pills-shipping" role="tabpanel" aria-labelledby="pills-shipping-tab">
                                            <?php foreach ($orders as $order) if ($order['status'] == 'Processed'){?>
                                                <div class="order-details mb-3">
                                                        <div class="order-table table-responsive" style="padding-top: 30px; padding-bottom: 20px;">
                                                            <table>
                                                            <?php foreach ($order['items'] as $item) {?>
                                                                <tr>
                                                                    <td rowspan="2" style="width: 15%; padding: 10px 0 0 0;"><img class="img-fluid" src="assets/img/index/product/<?=$item['img']?>"></td>
                                                                    <td colspan="2" style="vertical-align: bottom;"><h4 style="border: none; padding: 0; margin: 0;"><?=$item['name']?></h4></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="vertical-align: top;">Rp <?=$item['price']?></td>
                                                                    <td style="vertical-align: top; text-align: right;"><?=$item['qty']?>x</td>
                                                                </tr">
                                                            <?php }?>
                                                            </table>
                                                            <table class="table mt-2">
                                                                <tr>
                                                                    <td><?=count($order['items'])?> Products</td>
                                                                    <th class="text-right">Totals Rp <?=$order['total']?></th>
                                                                </tr>
                                                                <tr>
                                                                    <?php
                                                                    $date = new DateTime($order['processed_time']);
                                                                    $date->modify('+3 days');
                                                                    ?>
                                                                    <td>
                                                                        <p class="text-dark">
                                                                            You will receive the product before <?=$date->format('d-m-Y H:i')?>
                                                                            <br>
                                                                            See <a href="#my-orders" style="color: #fb2e86;" role="tab" data-toggle="pill">My Orders</a> for more information
                                                                        </p>
                                                                    </td>
                                                                    <form method="post">
                                                                        <input type="hidden" name="order_id" value="<?=$order['id']?>">
                                                                        <td class="text-right"><button type="submit" name="received" style="
                                                                        padding: 12px 42px;
                                                                        color: #fff;
                                                                        border: none;
                                                                        border-radius: 5px;
                                                                        text-align: center;
                                                                        position: relative;
                                                                        overflow: hidden;
                                                                        z-index: 1;
                                                                        background-color: #19d16f;">
                                                                    Product Received
                                                            </button>
                                                                </form>
                                                        </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="tab-pane fade" id="pills-completed" role="tabpanel" aria-labelledby="pills-completed-tab">
                                            <?php foreach ($orders as $order) if ($order['status'] == 'Received'){?>
                                                <div class="order-details mb-3">
                                                        <div class="order-table table-responsive" style="padding-top: 30px; padding-bottom: 20px;">
                                                            <table>
                                                            <?php foreach ($order['items'] as $item) {?>
                                                                <tr>
                                                                    <td rowspan="2" style="width: 15%; padding: 10px 0 0 0;"><img class="img-fluid" src="assets/img/index/product/<?=$item['img']?>"></td>
                                                                    <td colspan="2" style="vertical-align: bottom;"><h4 style="border: none; padding: 0; margin: 0;"><?=$item['name']?></h4></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="vertical-align: top;">Rp <?=$item['price']?></td>
                                                                    <td style="vertical-align: top; text-align: right;"><?=$item['qty']?>x</td>
                                                                </tr">
                                                            <?php }?>
                                                            </table>
                                                            <table class="table mt-2">
                                                                <tr>
                                                                    <td><?=count($order['items'])?> Products</td>
                                                                    <th class="text-right">Totals Rp <?=$order['total']?></th>
                                                                </tr>
                                                                <tr>
                                                                    <?php
                                                                    $date = new DateTime();
                                                                    $date->modify('+3 days');
                                                                    ?>
                                                                    <td>
                                                                        <p class="text-dark">
                                                                            Make payment before <?=$date->format('d-m-Y H:i')?>
                                                                            <br>
                                                                            See <a href="#my-orders" style="color: #fb2e86;" role="tab" data-toggle="pill">My Orders</a> for more information
                                                                        </p>
                                                                    </td>
                                                                    <td class="text-right"><a href="product.php" style="
                                                                        padding: 12px 42px;
                                                                        color: #fff;
                                                                        border: none;
                                                                        border-radius: 5px;
                                                                        text-align: center;
                                                                        position: relative;
                                                                        overflow: hidden;
                                                                        z-index: 1;
                                                                        background-color: #19d16f;">
                                                                    Rate Product
                                                            </a></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="address" role="tabpanel"
                                        aria-labelledby="address-tab">
                                        <div class="myaccount-content">
                                            <h3>Address</h3>
                                            <div class="account-details-form">
                                                <form method="POST">

                                                    <div class="row">

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>First Name <span
                                                                        class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="first_name" value="<?=$_SESSION['user']['first_name']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>Last Name <span class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="last_name" value="<?=$_SESSION['user']['last_name']?>">
                                                            </div>
                                                        </div>


                                                        <div class="col-12">
                                                            <div class="single-input-item">
                                                                <label>Province, City, District, Postal Code <span class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="address_line_1" value="<?=$_SESSION['user']['address_line_1']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-12">
                                                            <div class="single-input-item">
                                                                <label>Street Name, Building, No. House <span
                                                                        class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="address_line_2" value="<?=$_SESSION['user']['address_line_2']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-12">
                                                            <div class="single-input-item">
                                                                <input type="text" class="form-control" placeholder="Suite Unit, etc (optional)" name="address_line_3" value="<?=$_SESSION['user']['address_line_3']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>Email Address <span
                                                                        class="required">*</span></label>
                                                                <input type="email" class="form-control" required name="email" value="<?=$_SESSION['user']['email']?>">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="single-input-item">
                                                                <label>Phone <span class="required">*</span></label>
                                                                <input type="text" class="form-control" required name="phone" value="<?=$_SESSION['user']['phone']?>">
                                                            </div>
                                                        </div>

                                                    </div>
                                                    </fieldset>
                                                    <div class="single-input-item">
                                                        <button type="submit" name="save_address" class="default-btn">
                                                            Save Changes
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!--== End My Account Wrapper ==-->

    <!-- Footer Area -->
    <footer class="footer-area">
        <div class="container">
            <div class="footer-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6" style="padding-right: 150px; padding-left: 100px">
                        <h1>CetaQu</h1>
                        <h5>
                            A high-quality digital printing for your print division. CetaQu
                            Executing Excellence In Printing.
                        </h5>
                    </div>

                    <div class="col-lg-3 col-md-3" style="padding-right: 50px">
                        <div class="footer-list">
                            <h3>Information</h3>
                            <ul>
                                <li>
                                    <i class="bx bxs-chevron-right"></i>
                                    <a href="about.php">About Us</a>
                                </li>
                                <li>
                                    <i class="bx bxs-chevron-right"></i>
                                    <a href="terms-condition.php">Term & Conditions</a>
                                </li>
                                <li>
                                    <i class="bx bxs-chevron-right"></i>
                                    <a href="privacy-policy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <i class="bx bxs-chevron-right"></i>
                                    <a href="product.php">Products</a>
                                </li>
                                <li>
                                    <i class="bx bxs-chevron-right"></i>
                                    <a href="contact.php">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3">
                        <div class="footer-side-list">
                            <h3>Contact Us</h3>
                            <ul>
                                <li>
                                    <i class="bx bxs-phone"></i>
                                    <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                                </li>
                                <li>
                                    <i class="bx bxs-envelope"></i>
                                    <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                                </li>
                                <li>
                                    <i class="bx bxs-map"></i>
                                    <a
                                        href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk">Jl.
                                        Scientia Boulevard, <br />Tangerang, Banten 15810</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <p>©2021 CetaQu. All Rights Reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- Jquery Min JS -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <!-- Popper Min JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Meanmenu JS -->
    <script src="assets/js/meanmenu.js"></script>
    <!-- Wow JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Ajaxchimp Min JS -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <!-- Form Validator Min JS -->
    <script src="assets/js/form-validator.min.js"></script>
    <!-- Contact Form JS -->
    <script src="assets/js/contact-form-script.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/custom.js"></script>
</body>

</html>