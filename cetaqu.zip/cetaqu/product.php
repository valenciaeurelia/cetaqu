<?php
require "inc/conn.php";

$sql = "SELECT * FROM products";
$stmt = $conn->prepare($sql);
$stmt->execute();
$rs = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="zxx">
  <head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="assets/css/boxicons.min.css" />
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="assets/css/meanmenu.css" />
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/nice-select.min.css" />
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css" />

    <!-- Style Custom CSS -->
    <link rel="stylesheet" href="assets/css/style-custom.css" />

    <!-- Title -->
    <title>CetaQu</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png" />
  </head>

  <body>
    <!-- Preloader -->
    <div class="preloader">
      <div class="d-table">
        <div class="d-table-cell">
          <div class="pre-img">
            <img src="assets/img/CetaQu.png" alt="Logo" />
          </div>
          <div class="spinner">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="circle3"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <div class="navbar-area">
      <!-- Menu For Mobile Device -->
      <div class="mobile-nav">
        <a href="index.php" class="logo">
          <img src="assets/img/CetaQu.png" alt="Logo" />
        </a>
      </div>

      <!-- Menu For Desktop Device -->
      <div class="main-nav">
        <div class="container">
          <nav class="navbar navbar-expand-md">
            <a class="navbar-brand" href="index.php">
              <img src="assets/img/CetaQu.png" alt="Logo" />
            </a>

            <div
              class="collapse navbar-collapse mean-menu"
              id="navbarSupportedContent"
            >
              <ul class="navbar-nav m-auto">
                <li class="nav-item">
                  <a href="index.php" class="nav-link"> Home </a>
                </li>
                <li class="nav-item">
                  <a href="product.php" class="nav-link active"> Products </a>
                </li>
                <li class="nav-item">
                  <a href="about.php" class="nav-link"> About Us </a>
                </li>
                <li class="nav-item">
                  <a href="contact.php" class="nav-link"> Contact </a>
                </li>
              </ul>

              <div class="cart-area">
                <a href="product.php#search">
                  <i class="bx bx-search"></i>
                </a>
                <a href="wishlist.php">
                  <i class="bx bx-heart"></i>
                </a>
                <a href="account.php">
                  <i class="bx bx-user"></i>
                </a>
                <a href="cart.php">
                  <i class="bx bx-shopping-bag"></i>
                </a>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!-- End Navbar Area -->

    <!-- Inner Banner -->
    <div class="inner-banner inner-bg1">
      <div class="container">
        <div class="inner-title">
          <h3>Products</h3>
          <ul>
            <li>
              <a href="index.php">Home</a>
            </li>
            <li>
              <i class="bx bxs-chevrons-right"></i>
            </li>
            <li>Products</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Inner Banner End -->

    <!-- Product Area -->
    <section class="product-area pb-70" style="margin-top: 80px">
      <div class="container">
        <div class="section-title text-center">
          <span>Product</span>
          <h2>We Have Some Pre-ready Product</h2>
          <p>
            Each of the products can be personalized, with CetaQU you have
            extraordinary freedom to customize your orders.
          </p>
        </div>
        <div class="input-group" id="search">
          <input type="text" class="form-control search-input" placeholder="Search..." style="float: left;"/>
          <a class="search-btn" href="#search" style="float: left;"><i class="bx bx-search"></i></a>
        </div>
        <div class="row pt-45">
        <?php while ($data = $rs->fetch_assoc()) {
          ?>
          <div class="col-lg-4 col-md-6">
            <div class="product-card">
              <a href="product-details.php?product_id=<?=$data['id']?>">
                <img
                  src="assets/img/index/product/<?=$data['img']?>"
                  alt="Products Images"
                />
              </a>
              <div class="product-content">
                <a href="product-details.php?product_id=<?=$data['id']?>">
                  <h3><?=$data['name']?></h3>
                </a>
                <p><span>Rp. <?=$data['price']?></span></p>
                <div class="product-cart">
                  <ul>
                    <li>
                      <form action="wishlist.php" method="post" style="display: inline;">
                        <input type="hidden" name="product_id" value="<?=$data['id']?>">
                        <button style="border:none;" type="submit" name="wishlist">
                          <a>
                            <i class="bx bx-heart"></i>
                          </a>
                        </button>
                      </form>
                    </li>
                    <li>
                    <form action="cart.php" method="POST" style="display: inline;">
                      <input type="hidden" name="product_id" value="<?=$data['id']?>">
                      <input type="hidden" name="qty" class="qty-input" value="1">
                      <button type="submit" style="border:none;" name="add">
                        <a>
                          <i class="bx bx-shopping-bag"></i>
                        </a>
                      </button>
                    </form>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <?php }?>
        </div>
      </div>
    </section>
    <!-- Product Area End -->

    <!-- Footer Area -->
    <footer class="footer-area">
      <div class="container">
        <div class="footer-content">
          <div class="row">
            <div
              class="col-lg-6 col-md-6"
              style="padding-right: 150px; padding-left: 100px"
            >
              <h1>CetaQu</h1>
              <h5>
                A high-quality digital printing for your print division. CetaQu Executing Excellence In Printing.
              </h5>
            </div>

            <div class="col-lg-3 col-md-3" style="padding-right: 50px">
              <div class="footer-list">
                <h3>Information</h3>
                <ul>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="about.php">About Us</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="terms-condition.php">Term & Conditions</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="privacy-policy.php">Privacy Policy</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="product.php">Products</a>
                  </li>
                  <li>
                    <i class="bx bxs-chevron-right"></i>
                    <a href="contact.php">Contact</a>
                  </li>
                </ul>
              </div>
            </div>

            <div class="col-lg-3 col-md-3">
              <div class="footer-side-list">
                <h3>Contact Us</h3>
                <ul>
                  <li>
                    <i class="bx bxs-phone"></i>
                    <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                  </li>
                  <li>
                    <i class="bx bxs-envelope"></i>
                    <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                  </li>
                  <li>
                    <i class='bx bxs-map'></i>
                    <a href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk"
                    >Jl. Scientia Boulevard, <br>Tangerang, Banten 15810</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <p>©2021 CetaQu. All Rights Reserved</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer Area End -->

    <!-- Jquery Min JS -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <!-- Popper Min JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Bootstrap Min JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Meanmenu JS -->
    <script src="assets/js/meanmenu.js"></script>
    <!-- Wow JS -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Ajaxchimp Min JS -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <!-- Form Validator Min JS -->
    <script src="assets/js/form-validator.min.js"></script>
    <!-- Contact Form JS -->
    <script src="assets/js/contact-form-script.js"></script>
    <!-- Product Search JS -->
    <script src="assets/js/search.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/custom.js"></script>
  </body>
</html>
