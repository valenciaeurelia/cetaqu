
<?php
require "../inc/admin_required.php";
require "../inc/conn.php";
if(isset($_POST['process'])){
	$sql = "UPDATE orders SET processed_time = ? WHERE id = ?";
	$stmt = $conn->prepare($sql);
	$processed_time = date("Y-m-d H:i:s");
	$stmt->bind_param('si', $processed_time, $_POST['order_id']);
	$stmt->execute();
}
$sql = "SELECT * FROM order_items JOIN products ON order_items.product_id = products.id";
$stmt = $conn->prepare($sql);
$stmt->execute();
$order_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$sql = "SELECT * FROM orders";
$stmt = $conn->prepare($sql);
$stmt->execute();
$rs = $stmt->get_result();
$orders = [];
while ($row = $rs->fetch_assoc()) {
	$row['status'] = $row['received_time'] ? 'Received' : ($row['processed_time'] ? 'Processed' : ($row['payment_time'] ? 'Paid' : 'Not Paid'));
	$orders[$row['id']] = $row;
}
foreach ($order_items as $oi) {
	$total = $oi['qty'] * $oi['price'];
	$oi['total'] = $total;
	$orders[$oi['order_id']]['items'][] = $oi;
	$orders[$oi['order_id']]['total'] = isset($orders[$oi['order_id']]['total']) ? ($orders[$oi['order_id']]['total'] + $total) : (0 + $total);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Admin</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../assets/css/admin.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav d-flex justify-content-between">
      <li class="nav-item">
	  <h5><a class="nav-link" href="stocks.php">Manage Stocks</a></h5>
      </li>
      <li class="nav-item">
        <h5><a class="nav-link" href="../sign-out.php">Sign out</a></h5>
      </li>
    </ul>
  </div>
</nav>
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Manage <b>Orders</b></h2>
					</div>
				</div>
			</div>
			<table id="orders" class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Name</th>
						<th>Address</th>
						<th>Total Payment</th>
						<th>Status</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($orders as $id => $order) if($order['first_name']) {
					?>
					<tr>
						<td><?=$order['first_name']?> <?=$order['last_name']?></td>
						<td><?=$order['address_line_1']?> <?=$order['address_line_2']?> <?=$order['address_line_3']?></td>
						<td><?=$order['total']?></td>
						<td>
							<?=$order['status']?>
						</td>
						<td>
							<a href="#detailOrderModal<?=$id?>" class="none" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Detail">&#xe88f;</i></a>
							<?php if($order['payment_time'] && !$order['processed_time']) {?>
							<a href="#processOrderModal<?=$id?>" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Process">&#xe8ba;</i></a>
							<?php } ?>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>        
</div>
<?php foreach ($orders as $id => $order) {
?>
<div id="detailOrderModal<?=$id?>" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
				<div class="modal-header">						
					<h4 class="modal-title">Order Details</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<table class="table">
						<tr>
							<th role="heading">Name</th>
							<td><?=$order['first_name']?> <?=$order['last_name']?></td>
						</tr>
						<tr>
							<th role="heading">Address</th>
							<td><?=$order['address_line_1']?> <?=$order['address_line_2']?> <?=$order['address_line_3']?></td>
						</tr>
						<tr>
							<th role="heading">Phone Number</th>
							<td><?=$order['phone']?></td>
						</tr>
						<tr>
							<th role="heading">Email</th>
							<td><?=$order['email']?></td>
						</tr>
						<tr>
							<th role="heading">Attachment</th>
							<td>
								<?php if($order['file_upload']) {?>
								<a href="../<?=$order['file_upload']?>">File</a>
								<?php } else {?>
									None
								<?php }?>
							</td>
						</tr>
						<tr>
							<th role="heading">Status</th>
							<td><?=$order['status']?></td>
						</tr>
						<?php if($order['status'] != 'Not Paid') {?>
						<tr>
							<th role="heading">Payment Proof</th>
							<td>
									<a href="../<?=$order['payment_proof']?>" target="_blank"><img src="../<?=$order['payment_proof']?>" class="img-thumbnail"></a>
								</td>
							</tr>
							<tr>
								<th role="heading">Payment Bank</th>
								<td><?=$order['payment_bank']?></td>
							</tr>
							<tr>
								<th role="heading">Payment Sender</th>
								<td><?=$order['payment_sender']?></td>
							</tr>
							<?php }?>
						</table>
					<table class="table">
						<thead>
							<tr>
								<th>Name</th>
								<th>Count</th>
								<th>Subtotal</th>
							</tr>
						</thead>
						<tbody>
					<?php foreach ($order['items'] as $item) {
					?>
					<tr>
						<td><?=$item['name']?></td>
						<td><?=$item['qty']?> x <?=$item['price']?></td>
						<td><?=$item['total']?></td>
					</tr>
					<?php
					}
					?>
						</tbody>
						<tfoot>
							<th colspan="2">Total</th>
							<th><?=$order['total']?></th>
						</tfoot>
					</table>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Okay">
				</div>
		</div>
	</div>
</div>
<div id="processOrderModal<?=$id?>" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="POST">
				<div class="modal-header">						
					<h4 class="modal-title">Process Order</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<p>Mark this order as processed?</p>
					<p class="text-warning"><small>This action cannot be undone.</small></p>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
					<input type="hidden" name="order_id" value="<?=$id?>">
					<input type="submit" class="btn btn-info" name="process" value="Process">
				</div>
			</form>
		</div>
	</div>
</div>
<?php } ?>

<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
	$('#orders').DataTable();
	// Activate tooltip
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
</body>
</html>