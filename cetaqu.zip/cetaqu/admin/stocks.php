
<?php
require "../inc/admin_required.php";
require "../inc/conn.php";
if(isset($_POST['update'])){
	$sql = "UPDATE products SET in_stock = ? WHERE id = ?";
	$stmt = $conn->prepare($sql);
	$stmt->bind_param('ii', $_POST['in_stock'], $_POST['product_id']);
	$stmt->execute();
}
$sql = "SELECT * FROM products";
$stmt = $conn->prepare($sql);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Admin</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../assets/css/admin.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav d-flex justify-content-between">
      <li class="nav-item">
	  <h5><a class="nav-link" href="orders.php">Manage Orders</a></h5>
      </li>
      <li class="nav-item">
        <h5><a class="nav-link" href="../sign-out.php">Sign out</a></h5>
      </li>
    </ul>
  </div>
</nav>
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6 d-flex">
						<h2>Manage <b>Stocks</b></h2>
					</div>
				</div>
			</div>
			<table id="products" class="table table-striped table-hover">
				<thead>
					<tr>
						<th>No</th>
						<th>Name</th>
						<th>Price</th>
						<th>Status</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1;foreach ($products as $product) {
					?>
					<tr>
						<td><?=$i++?></td>
						<td><?=$product['name']?></td>
						<td><?=$product['price']?></td>
						<td><?=$product['in_stock'] == 1 ? 'In Stock' : 'Out of Stock'?></td>
						<td>
							<a href="#editStockModal<?=$product['id']?>" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Edit">	&#xe3c9;</i></a>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>        
</div>
<?php foreach ($products as $product) {
?>
<div id="editStockModal<?=$product['id']?>" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="POST">
				<div class="modal-header">						
					<h4 class="modal-title">Update Stock</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<select name="in_stock">
						<option value="0" <?=$product['in_stock'] == 0 ? 'selected' : ''?>>Out of Stock</option>
						<option value="1" <?=$product['in_stock'] == 1 ? 'selected' : ''?>>In Stock</option>
					</select>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
					<input type="hidden" name="product_id" value="<?=$product['id']?>">
					<input type="submit" class="btn btn-info" name="update" value="Update">
				</div>
			</form>
		</div>
	</div>
</div>
<?php } ?>

<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
	$('#products').DataTable();
	// Activate tooltip
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
</body>
</html>