<?php
require "inc/conn.php";

$product_id = @$_GET['product_id'];
$q = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($q);
$stmt->bind_param('i', $product_id);
$stmt->execute();
$rs = $stmt->get_result();
$data = $rs->fetch_assoc() ?? false;
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
  <!-- Required Meta Tags -->
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <!-- Animate Min CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <!-- Boxicons CSS -->
  <link rel="stylesheet" href="assets/css/boxicons.min.css" />
  <!-- Meanmenu CSS -->
  <link rel="stylesheet" href="assets/css/meanmenu.css" />
  <!-- Nice Select CSS -->
  <link rel="stylesheet" href="assets/css/nice-select.min.css" />
  <!-- Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="assets/css/responsive.css" />

  <!-- Style Custom CSS -->
  <link rel="stylesheet" href="assets/css/style-custom.css" />

  <!-- Title -->
  <title>CetaQu</title>

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png" />
</head>

<body>
  <!-- Preloader -->
  <div class="preloader">
    <div class="d-table">
      <div class="d-table-cell">
        <div class="pre-img">
          <img src="assets/img/CetaQu.png" alt="Logo" />
        </div>
        <div class="spinner">
          <div class="circle1"></div>
          <div class="circle2"></div>
          <div class="circle3"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Preloader -->

  <!-- Start Navbar Area -->
  <div class="navbar-area">
    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
      <a href="index.php" class="logo">
        <img src="assets/img/CetaQu.png" alt="Logo" />
      </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav">
      <div class="container">
        <nav class="navbar navbar-expand-md">
          <a class="navbar-brand" href="index.php">
            <img src="assets/img/CetaQu.png" alt="Logo" />
          </a>

          <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
            <ul class="navbar-nav m-auto">
              <li class="nav-item">
                <a href="index.php" class="nav-link"> Home </a>
              </li>
              <li class="nav-item">
                <a href="product.php" class="nav-link active"> Products </a>
              </li>
              <li class="nav-item">
                <a href="about.php" class="nav-link"> About Us </a>
              </li>
              <li class="nav-item">
                <a href="contact.php" class="nav-link"> Contact </a>
              </li>
            </ul>

            <div class="cart-area">
              <a href="product.php#search">
                <i class="bx bx-search"></i>
              </a>
              <a href="wishlist.php">
                <i class="bx bx-heart"></i>
              </a>
              <a href="account.php">
                <i class="bx bx-user"></i>
              </a>
              <a href="cart.php">
                <i class="bx bx-shopping-bag"></i>
              </a>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
  <!-- End Navbar Area -->
  <?php
  if ($data) {
  ?>
    <!-- Inner Banner -->
    <div class="inner-banner inner-bg2">
      <div class="container">
        <div class="inner-title">
          <h3>Product Details</h3>
          <ul>
            <li>
              <a href="index.php">Home</a>
            </li>
            <li>
              <i class="bx bxs-chevrons-right"></i>
            </li>
            <li>
              <a href="product.php">Products</a>
            </li>
            <li>
              <i class="bx bxs-chevrons-right"></i>
            </li>
            <li>Product Details</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Inner Banner End -->

    <!-- Product Detls -->
    <section class="product-detls ptb-100">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-12">
            <div class="product-detls-image">
              <img src="assets/img/index/product/<?= $data['img'] ?>" alt="Image" />
            </div>
          </div>

          <div class="col-lg-6 col-md-12">
            <div class="product-desc">
              <h3><?= $data['name'] ?></h3>
              <div class="price">
                <span class="new-price">Rp. <?= $data['price'] ?></span>
              </div>

              <div class="product-review">
                <a href="#" class="rating-count">3 reviews</a>
              </div>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et. Lorem ipsum dolor sit
                amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et.
              </p>

              <div class="input-count-area">
                <h3>Quantity</h3>
                <div class="input-counter">
                  <span class="minus-btn"><i class="bx bx-minus"></i></span>
                  <input id="qty" type="text" min="1" value="1" />
                  <span class="plus-btn"><i class="bx bx-plus"></i></span>
                </div>
              </div>

              <div class="product-add">
                <form action="checkout.php" method="POST" style="display: inline;">
                  <input type="hidden" name="product_id" value="<?=$_GET['product_id']?>">
                  <input type="hidden" name="qty" class="qty-input" value="1">
                  <button type="submit" class="default-btn" name="buy">
                    <i class="fas fa-cart-plus"></i> Buy Now!
                  </button>
                </form>
                <form action="cart.php" method="POST" style="display: inline;">
                    <input type="hidden" name="product_id" value="<?=$_GET['product_id']?>">
                    <input type="hidden" name="qty" class="qty-input" value="1">
                    <button type="submit" class="default-btn" name="add">
                      <i class="fas fa-cart-plus"></i> Add To Cart
                    </button>
                </form>
              </div>

              <div class="product-share">
                <ul>
                  <li>
                    <span>Share:</span>
                  </li>
                  <li>
                    <a href="#" target="_blank">
                      <i class="bx bxl-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" target="_blank">
                      <i class="bx bxl-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" target="_blank">
                      <i class="bx bxl-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" target="_blank">
                      <i class="bx bxl-linkedin"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-lg-12 col-md-12">
            <div class="tab product-detls-tab">
              <div class="row">
                <div class="col-lg-12 col-md-12">
                  <ul class="tabs">
                    <li>
                      <a href="#"> Description</a>
                    </li>

                    <li>
                      <a href="#">Additional information </a>
                    </li>

                    <li>
                      <a href="#"> Reviews </a>
                    </li>
                  </ul>
                </div>

                <div class="col-lg-12 col-md-12">
                  <div class="tab_content current active">
                    <div class="tabs_item current">
                      <div class="product-detls-tab-content">
                        <p>
                          Design inspiration lorem ipsum dolor sit amet,
                          consectetuer adipiscing elit. Morbi commodo, ipsum sed
                          pharetra gravida, orci magna rhoncus neque, id
                          pulvinar odio lorem non turpis. Nullam sit amet enim.
                          Suspendisse id velit vitae ligula volutpat
                          condimentum. Aliquam erat volutpat. Sed quis velit.
                          Nulla facilisi. Nulla libero. Vivamus pharetra posuere
                          sapien. Nam consectetuer. Sed aliquam, nunc eget
                          euismod ullamcorper, lectus nunc ullamcorper orci,
                          fermentum bibendum enim nibh eget ipsum. Nam
                          consectetuer. Sed aliquam, nunc eget euismod
                          ullamcorper, lectus nunc ullamcorper orci, fermentum
                          bibendum enim nibh eget ipsum. Nulla libero. Vivamus
                          pharetra posuere sapien.
                        </p>
                      </div>
                    </div>

                    <div class="tabs_item">
                      <div class="product-detls-tab-content">
                        <ul class="additional-information">
                          <li>
                            <span>SKU:</span><span id="detailSku"><?= $data['sku'] ?></span>
                          </li>
                          <li>
                            <span>Size:</span>
                            <?php
                            $q = "SELECT size FROM sizes WHERE product_id = ?";
                            $stmt = $conn->prepare($q);
                            $stmt->bind_param('i', $product_id);
                            $stmt->execute();
                            $rs = $stmt->get_result();
                            $sizes = $rs->fetch_array();
                            $size = $sizes['size'];
                            while ($sizes = $rs->fetch_array()) {
                              $size .= ", " . $sizes['size'];
                            }
                            ?>
                            <span id="detailSize"><?= $size ?></span>
                          </li>
                          <li>
                            <span>Min Order:</span><span id="detailMinOrder"><?= $data['min_order'] ?></span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div class="tabs_item">
                      <div class="product-detls-tab-content">
                        <div class="product-review-form">
                          <h3>Customer Reviews</h3>
                          <div class="review-title">
                            <div class="rating">
                              <i class="bx bxs-star"></i>
                              <i class="bx bxs-star"></i>
                              <i class="bx bxs-star"></i>
                              <i class="bx bxs-star"></i>
                              <i class="bx bxs-star-half"></i>
                            </div>
                            <p>Based on 3 reviews</p>
                            <a href="#" class="default-btn btn-right">Write a Review <span></span></a>
                          </div>

                          <div class="review-comments">
                            <div class="review-item">
                              <div class="rating">
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star-half"></i>
                              </div>
                              <h3>Good</h3>
                              <span><strong>Admin</strong> on
                                <strong>June 21, 2020</strong></span>
                              <p>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut
                                enim ad minim veniam, quis nostrud exercitation.
                              </p>
                              <a href="#" class="review-report-link">Report as Inappropriate</a>
                            </div>

                            <div class="review-item">
                              <div class="rating">
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star-half"></i>
                              </div>
                              <h3>Good</h3>
                              <span><strong>Admin</strong> on
                                <strong>June 21, 2020</strong></span>
                              <p>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut
                                enim ad minim veniam, quis nostrud exercitation.
                              </p>

                              <a href="#" class="review-report-link">Report as Inappropriate</a>
                            </div>

                            <div class="review-item">
                              <div class="rating">
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star"></i>
                                <i class="bx bxs-star-half"></i>
                              </div>
                              <h3>Good</h3>
                              <span><strong>Admin</strong> on
                                <strong>June 21, 2020</strong></span>
                              <p>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut
                                enim ad minim veniam, quis nostrud exercitation.
                              </p>

                              <a href="#" class="review-report-link">Report as Inappropriate</a>
                            </div>
                          </div>

                          <div class="review-form">
                            <h3>Write a Review</h3>
                            <div class="contact-wrap-form">
                              <form>
                                <div class="row">
                                  <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                      <input type="text" name="name" id="name" class="form-control" required data-error="Please enter your name" placeholder="Your Name" />
                                    </div>
                                  </div>

                                  <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                      <input type="email" name="email" id="email" class="form-control" required data-error="Please enter your email" placeholder="Your Email" />
                                    </div>
                                  </div>

                                  <div class="col-lg-12 col-sm-12">
                                    <div class="form-group">
                                      <input type="text" name="msg_subject" id="msg_subject" class="form-control" required data-error="Please enter your subject" placeholder="Your Subject" />
                                    </div>
                                  </div>

                                  <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                      <textarea name="message" class="form-control" id="message" cols="30" rows="8" required data-error="Write your message" placeholder="Your Message"></textarea>
                                    </div>
                                  </div>

                                  <div class="col-lg-12 col-md-12">
                                    <button type="submit" class="default-btn page-btn">
                                      Submit Review
                                    </button>
                                  </div>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Product Detls End -->
  <?php
  } else {
  ?>

  <?php
  }
  ?>

  <!-- Footer Area -->
  <footer class="footer-area">
    <div class="container">
      <div class="footer-content">
        <div class="row">
          <div class="col-lg-6 col-md-6" style="padding-right: 150px; padding-left: 100px">
            <h1>CetaQu</h1>
            <h5>
              A high-quality digital printing for your print division. CetaQu Executing Excellence In Printing.
            </h5>
          </div>

          <div class="col-lg-3 col-md-3" style="padding-right: 50px">
            <div class="footer-list">
              <h3>Information</h3>
              <ul>
                <li>
                  <i class="bx bxs-chevron-right"></i>
                  <a href="about.php">About Us</a>
                </li>
                <li>
                  <i class="bx bxs-chevron-right"></i>
                  <a href="terms-condition.php">Term & Conditions</a>
                </li>
                <li>
                  <i class="bx bxs-chevron-right"></i>
                  <a href="privacy-policy.php">Privacy Policy</a>
                </li>
                <li>
                  <i class="bx bxs-chevron-right"></i>
                  <a href="product.php">Products</a>
                </li>
                <li>
                  <i class="bx bxs-chevron-right"></i>
                  <a href="contact.php">Contact</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-lg-3 col-md-3">
            <div class="footer-side-list">
              <h3>Contact Us</h3>
              <ul>
                <li>
                  <i class="bx bxs-phone"></i>
                  <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                </li>
                <li>
                  <i class="bx bxs-envelope"></i>
                  <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                </li>
                <li>
                  <i class="bx bxs-map"></i>
                  <a href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk">Jl. Scientia Boulevard, <br />Tangerang, Banten 15810</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-12">
            <p>©2021 CetaQu. All Rights Reserved</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- Footer Area End -->

  <!-- Jquery Min JS -->
  <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
  <!-- Popper Min JS -->
  <script src="assets/js/popper.min.js"></script>
  <!-- Bootstrap Min JS -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- Meanmenu JS -->
  <script src="assets/js/meanmenu.js"></script>
  <!-- Wow JS -->
  <script src="assets/js/wow.min.js"></script>
  <!-- Nice Select JS -->
  <script src="assets/js/jquery.nice-select.min.js"></script>
  <!-- Ajaxchimp Min JS -->
  <script src="assets/js/jquery.ajaxchimp.min.js"></script>
  <!-- Form Validator Min JS -->
  <script src="assets/js/form-validator.min.js"></script>
  <!-- Contact Form JS -->
  <script src="assets/js/contact-form-script.js"></script>
  <!-- Custom JS -->
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/qty.js"></script>
</body>

</html>