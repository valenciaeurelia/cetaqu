<?php
require "inc/login_redirect.php";
require "inc/conn.php";
if (isset($_POST['signup'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $username, $email, $password_hash);
    $alert = ['success'=>false, 'msg'=>'Sign up failed'];
    if ($stmt->execute()) {
        $alert = ['success'=>true, 'msg'=>'Signed up successfully'];
    }
}
?>

<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Owl Carousel CSS --> 
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!-- Style Custom CSS -->
        <link rel="stylesheet" href="assets/css/style-custom.css">

        <!-- Title -->
        <title>CetaQu</title>
        
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png">
    </head>

    <body>
        <!-- Preloader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="pre-img">
                        <img src="assets/img/CetaQu.png" alt="Logo">
                    </div>
                    <div class="spinner">
                        <div class="circle1"></div>
                        <div class="circle2"></div>
                        <div class="circle3"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <div class="navbar-area" >
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/CetaQu.png" alt="Logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md" >
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/CetaQu.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link ">
                                        Home 
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="product.php" class="nav-link ">
                                        Products
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="about.php" class="nav-link">
                                        About Us
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="contact.php" class="nav-link">
                                        Contact
                                    </a>
                                </li>
                            </ul>

                            <div class="cart-area">
                                <a href="product.php#search">
                                    <i class='bx bx-search'></i>
                                </a>
                                <a href="wishlist.php">
                                    <i class='bx bx-heart'></i>
                                </a>
                                <a href="account.php" style="color:#FB2E86;">
                                    <i class='bx bx-user'></i>
                                </a>
                                <a href="cart.php">
                                    <i class='bx bx-shopping-bag'></i>
                                </a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        
        <!-- Inner Banner -->
        <div class="inner-banner inner-bg18">
            <div class="container">
                <div class="inner-title">
                    <h3>Sign Up</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <i class='bx bxs-chevrons-right'></i>
                        </li>
                        <li>Sign Up</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Inner Banner End -->
        
        <!-- Start Sign Up Area -->
		<section class="sing-up-area ptb-100">
			<div class="container">
				<div class="contact-wrap-form sing-in-width">
                    <div class="section-title text-center pb-3">
                        <span>Sign Up</span>
					    <h2>Create An Account!</h2>
                    </div>
					<form method="post" action="">
						<div class="row">
							<div class="col-12">
                            <?php if(isset($alert)) {
                                ?>
                                <div class="alert alert-<?=$alert['success']?'success':'danger'?>" role="alert">
                                <?=$alert['msg']?>
                                </div>
                                <?php
                            }
                            ?>
								<div class="form-group">
									<input class="form-control" required type="text" name="username" placeholder="Username">
								</div>
                            </div>
                            
                            <div class="col-12">
								<div class="form-group">
									<input class="form-control" required type="email" name="email" placeholder="Email">
								</div>
                            </div>

							<div class="col-12">
								<div class="form-group">
									<input class="form-control" required type="password" name="password" placeholder="Password">
								</div>
							</div>

							<div class="col-12 text-center">
								<button class="default-btn btn-two sing-btn" type="submit" name="signup">
									Sign Up
								</button>
							</div>

							<div class="col-12">
								<p class="account-desc">
									Already have an account? 
									<a href="sign-in.php">Sign In</a>
								</p>
							</div>
						</div>
					</form>
				</div>
			</div>
		</section>
		<!-- End Sign Up Area -->

        
        <!-- Footer Area -->
        <footer class="footer-area">
            <div class="container">

                <div class="footer-content">
                    <div class="row">
                        <div class="col-lg-6 col-md-6" style="padding-right: 150px; padding-left: 100px;">
                            <h1>CetaQu</h1>
                            <h5>A high-quality digital printing for your print division. CetaQu Executing Excellence In Printing.</h5>
                        </div>

                        <div class="col-lg-3 col-md-3" style="padding-right: 50px; ">
                            <div class="footer-list">
                                <h3>Information</h3>
                                <ul>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="about.php">About Us</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="terms-condition.php">Term & Conditions</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="privacy-policy.php">Privacy Policy</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="product.php">Products</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="contact.php">Contact</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3">
                            <div class="footer-side-list">
                                <h3>Contact Us</h3>
                                <ul>
                                    <li>
                                        <i class='bx bxs-phone'></i>
                                        <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-envelope'></i>
                                        <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-map'></i>
                                        <a href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk"
                                        >Jl. Scientia Boulevard, <br>Tangerang, Banten 15810</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-md-12">
                            <p>
                                ©2021 CetaQu. All Rights Reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->
        <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Popper Min JS -->
        <script src="assets/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Wow JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Nice Select JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
    </body>
</html>