<?php
require "inc/login_required.php";
require "inc/conn.php";
require "inc/functions.php";

if(isset($_POST['pay'])){
    $ext = array_pop(explode('.', $_FILES['payment_proof']['name']));
    $namaSementara = $_FILES['payment_proof']['tmp_name'];
    $dirUpload = "assets/img/uploads/";
    $fullPath = $dirUpload . 'payment-' . rand_str(8) . "." . $ext;
    $terupload = move_uploaded_file($namaSementara, $fullPath);
    $payment_bank = $_POST['payment_bank'];
    $payment_sender = $_POST['payment_sender'];
    $order_id = $_POST['order_id'];
    $payment_time=date("Y-m-d H:i:s");
    $sql = "UPDATE orders SET payment_time = ?, payment_proof = ?, payment_bank = ?, payment_sender = ? WHERE id  = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $payment_time, $fullPath, $payment_bank, $payment_sender, $order_id);
    $stmt->execute();
    header("Location: order-complete.php?order_id=$order_id");
    exit;
}

if (!isset($_GET['order_id'])) header('Location: index.php');
$order_id = $_GET['order_id'];
$sql = "SELECT * FROM orders WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ii', $_GET['order_id'], $_SESSION['user_id']);
$stmt->execute();
$rs = $stmt->get_result()->fetch_assoc();
if (!$rs) header('Location: index.php');
if (!$rs['first_name']) header("Location: checkout.php?order_id=$order_id");
if ($rs['payment_proof']) header("Location: order-complete.php?order_id=$order_id");

$sql = "SELECT * FROM order_items JOIN products ON products.id=order_items.product_id WHERE order_items.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_GET['order_id']);
$stmt->execute();
$rs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
// var_dump($rs);
if (!$rs) header('Location: index.php');
?>
<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Owl Carousel CSS --> 
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!-- Style Custom CSS -->
        <link rel="stylesheet" href="assets/css/style-custom.css">

        <!-- Title -->
        <title>CetaQu</title>
        
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="assets/img/Favicon-CetaQu.png">
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="pre-img">
                        <img src="assets/img/CetaQu.png" alt="Logo">
                    </div>
                    <div class="spinner">
                        <div class="circle1"></div>
                        <div class="circle2"></div>
                        <div class="circle3"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <div class="navbar-area" >
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.php" class="logo">
                    <img src="assets/img/CetaQu.png" alt="Logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md" >
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/CetaQu.png" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link ">
                                        Home 
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="product.php" class="nav-link ">
                                        Products
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="about.php" class="nav-link">
                                        About Us
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="contact.php" class="nav-link">
                                        Contact
                                    </a>
                                </li>
                            </ul>

                            <div class="cart-area">
                                <a href="product.php#search">
                                    <i class='bx bx-search'></i>
                                </a>
                                <a href="wishlist.php">
                                    <i class='bx bx-heart'></i>
                                </a>
                                <a href="account.php">
                                    <i class='bx bx-user'></i>
                                </a>
                                <a href="cart.php"  style="color:#FB2E86;">
                                    <i class='bx bx-shopping-bag'></i>
                                </a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        
        <!-- Inner Banner -->
        <div class="inner-banner inner-bg20">
            <div class="container">
                <div class="inner-title">
                    <h3>Payment</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <i class='bx bxs-chevrons-right'></i>
                        </li>
                        <li>Payment</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Inner Banner End -->

         <!-- Checkout Area -->
		<section class="checkout-area pt-100 pb-70">
			<div class="container">

				<form action="payment.php" method="POST" enctype="multipart/form-data">
					<div class="row">

                        <div class="col-lg-6 col-md-12">
                            <div class="order-details">
                                <div class="order-table table-responsive">
                                    <h3>Your Order</h3>
                                    <table class="table">

                                        <tbody>
                                            <?php $total=0;foreach ($rs as $data) {?>
                                            <tr>
                                                <td class="product-name" style="width: 20%;">
                                                    <img src="assets/img/index/product/<?=$data['img']?>" alt="">
                                                </td>
                                                <td class="product-name">
                                                    <span style="font-size: large; font-weight:bold;"><?=$data['name']?></span>
                                                    <br>
                                                    <span class="subtotal-amount" style=" color:#151875;">Rp. <?=$data['price']*$data['qty']?></span>
                                                </td>

                                                <td class="product-total" style="vertical-align:bottom; text-align:center;">
                                                    <?=$data['qty']?>x
                                                    <?php $total+=$data['price']*$data['qty'];?>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                            <tr>
                                                <td class="order-subtotal" colspan="2">
                                                    <span>Cart Subtotal</span>
                                                </td>

                                                <td class="order-subtotal-price">
                                                    <span class="order-subtotal-amount">Rp. <?=$total?></span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td class="order-shipping" colspan="2">
                                                    <span>Shipping</span>
                                                </td>

                                                <td class="shipping-price">
                                                    <span>Rp. 15.000</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td class="order-shipping" colspan="2">
                                                    <span>Coupon</span>
                                                </td>

                                                <td class="shipping-price">
                                                    <span>Rp. 0</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td class="total-price" colspan="2">
                                                    <span>Order Total</span>
                                                </td>

                                                <td class="product-subtotal">
                                                    <span class="subtotal-amount">Rp. <?=$total+15000?></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <input type="hidden" name="order_id" value="<?=$_GET['order_id']?>">
                            </div>
                        </div>

						<div class="col-lg-6 col-md-12">
							<div class="billing-details">
								<h3 class="title">Payment</h3>
								<h6 class="subtitle pb-3">Transfer Bank</h6>

                                <table>
                                    <tr>
                                        <td rowspan="3" style="width: 20%; padding-right: 20px;"><img src="assets/img/logo-bca.png" alt=""></td>
                                        <td>Bank Central Asia</td>
                                    </tr>
                                    <tr>
                                        <td>2208 1996</td>
                                    </tr>
                                    <tr>
                                        <td>CetaQu</td>
                                    </tr>
                                    <tr>
                                        <td rowspan="3" style="width: 20%; padding-right: 20px;"><img src="assets/img/logo-mandiri.png" alt=""></td>
                                        <td>Bank Mandiri</td>
                                    </tr>
                                    <tr>
                                        <td>2208 1996</td>
                                    </tr>
                                    <tr>
                                        <td>CetaQu</td>
                                    </tr>
                                </table>

								<div class="row mt-5">
									<div class="col-lg-12 col-md-6">
										<div class="form-group">
											<label>Upload Bukti Transfer <span class="required">*</span></label>
											<input type="file" class="form-control-file" name="payment_proof" accept="image/*" required>
										</div>
									</div>

									<div class="col-lg-12 col-md-6">
										<div class="form-group">
											<label>Asal Bank <span class="required">*</span></label>
											<input type="text" class="form-control" name="payment_bank" required>
										</div>
									</div>


									<div class="col-lg-12 col-md-6">
										<div class="form-group">
											<label>Nama Pengirim <span class="required">*</span></label>
											<input type="text" class="form-control" name="payment_sender" required>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
                    <div class="row d-flex justify-content-center">
                        <button type="submit" name="pay" class="default-btn" style="border:none; width:300px">
                            Continue to Order
                                </button>
                    </div>
                    <div class="row d-flex justify-content-center mt-2">
                                    <button style="background-color: #eee;
                                        color: #aaa;
                                        width: 300px;
                                        padding: 12px 42px;
                                        border-radius: 5px;
                                        border:none;
                                        text-align: center;
                                        position: relative;
                                        overflow: hidden;
                                        z-index: 1;" onclick="history.back()">Cancel</button>

                    </div>
				</form>
			</div>
		</section>
		<!-- Checkout Area End -->

        
        <!-- Footer Area -->
        <footer class="footer-area">
            <div class="container">

                <div class="footer-content">
                    <div class="row">
                        <div class="col-lg-6 col-md-6" style="padding-right: 150px; padding-left: 100px;">
                            <h1>CetaQu</h1>
                            <h5>A high-quality digital printing for your print division. CetaQu Executing Excellence In Printing.</h5>
                        </div>

                        <div class="col-lg-3 col-md-3" style="padding-right: 50px; ">
                            <div class="footer-list">
                                <h3>Information</h3>
                                <ul>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="about.php">About Us</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="terms-condition.php">Term & Conditions</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="privacy-policy.php">Privacy Policy</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="product.php">Products</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-chevron-right'></i>
                                        <a href="contact.php">Contact</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3">
                            <div class="footer-side-list">
                                <h3>Contact Us</h3>
                                <ul>
                                    <li>
                                        <i class='bx bxs-phone'></i>
                                        <a href="tel:+62 1234 56 7891">+62 1234 56 7891</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-envelope'></i>
                                        <a href="mailto:CetaQu@gmail.com">CetaQu@gmail.com</a>
                                    </li>
                                    <li>
                                        <i class='bx bxs-map'></i>
                                        <a href="https://www.google.com/maps/place/Universitas+Multimedia+Nusantara/@-6.2595421,106.615588,17z/data=!4m9!1m2!2m1!1sUniversitas+Multimedia+Nusantara!3m5!1s0x2e69fb56b25975f9:0x50c7d605ba8542f5!8m2!3d-6.2575699!4d106.6183308!15sCiBVbml2ZXJzaXRhcyBNdWx0aW1lZGlhIE51c2FudGFyYZIBCnVuaXZlcnNpdHk">Jl. Scientia Boulevard, <br>Tangerang, Banten 15810</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-md-12">
                            <p>
                                ©2021 CetaQu. All Rights Reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->


        <!-- Jquery Min JS -->
        <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
        <!-- Popper Min JS -->
        <script src="assets/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Wow JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Nice Select JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>
        
    </body>
</html>